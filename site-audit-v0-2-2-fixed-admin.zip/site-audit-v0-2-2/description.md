# Description

Site-Audit-V0.2.2 adds a WordPress admin screen and private REST API endpoints for basic site auditing.

It shows a site snapshot, theme snapshot, and direct JSON endpoint links inside the WordPress sidebar under **Site Audit**.

It is intentionally cautious: it inspects structure, but does not edit theme files or execute arbitrary code.
