<?php
/**
 * Plugin Name: Site-Audit-V0.2.2
 * Plugin URI: https://github.com/TABARC-Code/site-audit-v0-2-2
 * Description: Private REST API endpoints and admin tools for WordPress auditing and structured site inspection.
 * Version: 0.2.2
 * Author: TABARC-Code
 * Requires at least: 6.0
 * Requires PHP: 8.0
 * Text Domain: site-audit-v0-2-2
 * License: MIT
 */

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Register REST API routes.
 *
 * This is the useful bit: WordPress becomes queryable instead of being
 * a dusty cupboard full of pages nobody remembers creating.
 */
add_action('rest_api_init', function () {

    register_rest_route('site-audit/v1', '/summary', [
        'methods'  => 'GET',
        'callback' => 'sa022_get_summary',
        'permission_callback' => 'sa022_permission_check',
    ]);

    register_rest_route('site-audit/v1', '/pages', [
        'methods'  => 'GET',
        'callback' => 'sa022_get_pages',
        'permission_callback' => 'sa022_permission_check',
    ]);

    register_rest_route('site-audit/v1', '/theme', [
        'methods'  => 'GET',
        'callback' => 'sa022_get_theme',
        'permission_callback' => 'sa022_permission_check',
    ]);

});

/**
 * Only users who can edit pages can access audit data.
 * Not perfect. Sensible enough for v0.2.2.
 */
function sa022_permission_check() {
    return current_user_can('edit_pages');
}

/**
 * Add the sidebar admin page.
 */
add_action('admin_menu', 'sa022_register_admin_page');

function sa022_register_admin_page() {
    add_menu_page(
        'Site-Audit-V0.2.2',
        'Site Audit',
        'edit_pages',
        'site-audit-v0-2-2',
        'sa022_render_admin_page',
        'dashicons-search',
        81
    );
}

/**
 * Render the admin page.
 */
function sa022_render_admin_page() {

    if (!current_user_can('edit_pages')) {
        wp_die(__('You do not have permission to access this page.', 'site-audit-v0-2-2'));
    }

    $summary_endpoint = esc_url(rest_url('site-audit/v1/summary'));
    $pages_endpoint   = esc_url(rest_url('site-audit/v1/pages'));
    $theme_endpoint   = esc_url(rest_url('site-audit/v1/theme'));

    $summary = sa022_get_summary();
    $theme   = sa022_get_theme();

    ?>
    <div class="wrap">
        <h1>Site-Audit-V0.2.2</h1>

        <p>
            Private WordPress REST API audit layer for structured site inspection.
            No grand claims. No magic rebuild button. Just useful visibility.
        </p>

        <p>
            <strong>Status:</strong>
            <span style="display:inline-block;padding:3px 8px;border-radius:999px;background:#d1fae5;color:#065f46;font-weight:600;">
                Active
            </span>
        </p>

        <hr>

        <h2>Site Snapshot</h2>

        <table class="widefat striped" style="max-width: 900px;">
            <tbody>
                <tr>
                    <th scope="row">Site Name</th>
                    <td><?php echo esc_html($summary['site_name']); ?></td>
                </tr>
                <tr>
                    <th scope="row">Site URL</th>
                    <td><?php echo esc_html($summary['site_url']); ?></td>
                </tr>
                <tr>
                    <th scope="row">WordPress Version</th>
                    <td><?php echo esc_html($summary['wp_version']); ?></td>
                </tr>
                <tr>
                    <th scope="row">Active Theme</th>
                    <td><?php echo esc_html($summary['active_theme']); ?></td>
                </tr>
                <tr>
                    <th scope="row">Published Posts</th>
                    <td><?php echo esc_html($summary['posts']); ?></td>
                </tr>
                <tr>
                    <th scope="row">Published Pages</th>
                    <td><?php echo esc_html($summary['pages']); ?></td>
                </tr>
            </tbody>
        </table>

        <h2 style="margin-top:28px;">REST Endpoints</h2>

        <p>
            Open these while logged into WordPress. They return raw JSON.
            Functional, not glamorous. Like most things that actually work.
        </p>

        <table class="widefat striped" style="max-width: 900px;">
            <thead>
                <tr>
                    <th>Endpoint</th>
                    <th>Purpose</th>
                    <th>Open</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td><code>/wp-json/site-audit/v1/summary</code></td>
                    <td>Site name, URL, WordPress version, active theme, post/page counts.</td>
                    <td><a class="button button-secondary" href="<?php echo $summary_endpoint; ?>" target="_blank">Open JSON</a></td>
                </tr>
                <tr>
                    <td><code>/wp-json/site-audit/v1/pages</code></td>
                    <td>Page inventory with IDs, slugs, status, templates and word counts.</td>
                    <td><a class="button button-secondary" href="<?php echo $pages_endpoint; ?>" target="_blank">Open JSON</a></td>
                </tr>
                <tr>
                    <td><code>/wp-json/site-audit/v1/theme</code></td>
                    <td>Active theme metadata and template information.</td>
                    <td><a class="button button-secondary" href="<?php echo $theme_endpoint; ?>" target="_blank">Open JSON</a></td>
                </tr>
            </tbody>
        </table>

        <h2 style="margin-top:28px;">Theme Snapshot</h2>

        <table class="widefat striped" style="max-width: 900px;">
            <tbody>
                <tr>
                    <th scope="row">Theme Name</th>
                    <td><?php echo esc_html($theme['name']); ?></td>
                </tr>
                <tr>
                    <th scope="row">Theme Version</th>
                    <td><?php echo esc_html($theme['version']); ?></td>
                </tr>
                <tr>
                    <th scope="row">Theme Author</th>
                    <td><?php echo esc_html(wp_strip_all_tags($theme['author'])); ?></td>
                </tr>
                <tr>
                    <th scope="row">Template</th>
                    <td><?php echo esc_html($theme['template']); ?></td>
                </tr>
                <tr>
                    <th scope="row">Stylesheet</th>
                    <td><?php echo esc_html($theme['stylesheet']); ?></td>
                </tr>
            </tbody>
        </table>

        <h2 style="margin-top:28px;">Project</h2>

        <p>
            <a href="https://github.com/TABARC-Code/site-audit-v0-2-2" target="_blank" rel="noopener noreferrer">
                GitHub Repository
            </a>
        </p>
    </div>
    <?php
}

function sa022_get_summary() {
    return [
        'site_name'    => get_bloginfo('name'),
        'site_url'     => get_site_url(),
        'wp_version'   => get_bloginfo('version'),
        'active_theme' => wp_get_theme()->get('Name'),
        'posts'        => wp_count_posts('post')->publish ?? 0,
        'pages'        => wp_count_posts('page')->publish ?? 0,
    ];
}

function sa022_get_pages() {
    $pages = get_posts([
        'post_type'   => 'page',
        'post_status' => ['publish', 'draft', 'private'],
        'numberposts' => -1,
    ]);

    return array_map(function ($page) {
        return [
            'id'         => $page->ID,
            'title'      => get_the_title($page),
            'slug'       => $page->post_name,
            'status'     => $page->post_status,
            'modified'   => $page->post_modified,
            'link'       => get_permalink($page),
            'template'   => get_page_template_slug($page->ID),
            'word_count' => str_word_count(wp_strip_all_tags($page->post_content)),
        ];
    }, $pages);
}

function sa022_get_theme() {
    $theme = wp_get_theme();

    return [
        'name'       => $theme->get('Name'),
        'version'    => $theme->get('Version'),
        'author'     => $theme->get('Author'),
        'template'   => $theme->get_template(),
        'stylesheet' => $theme->get_stylesheet(),
        'theme_root' => get_theme_root(),
    ];
}
