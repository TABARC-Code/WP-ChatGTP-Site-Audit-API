# Site-Audit-V0.2.2

Private REST API endpoints and admin tools for WordPress auditing and structured site inspection.

## Use

After activation, go to:

```text
WordPress Admin → Site Audit
```

## REST Endpoints

```text
/wp-json/site-audit/v1/summary
/wp-json/site-audit/v1/pages
/wp-json/site-audit/v1/theme
```

You must be logged in as a user who can edit pages.

## Author

TABARC-Code
